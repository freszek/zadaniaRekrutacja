<template>
  <div id="app" class="container">
    <h1 class="text-center my-4">Tabela użytkowników</h1>
    <UsersTable />
  </div>
</template>

<script>
import UsersTable from "./components/UsersTable.vue";

export default {
  components: {
    UsersTable
  }
};
</script>

<style>
</style>
