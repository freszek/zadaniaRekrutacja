<template>
  <div>
    <div class="d-flex justify-content-between mb-3">
      <div>
        <input type="text" v-model="search" placeholder="Szukaj..." />
        <button @click="fetchData" class="btn btn-warning">RESET</button>
      </div>
      <div>
        API Key:
        <input type="text" v-model="apiKey" @change="storeApiKey" />
      </div>
    </div>

    <table class="table table-responsive table-striped">
      <thead>
        <tr>
          <th @click="sort('id')">ID</th>
          <th @click="sort('name')">Nazwa</th>
          <th @click="sort('login')">Login</th>
          <th @click="sort('date_added')">Data dodania</th>
          <th>Akcje</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in paginatedUsers" :key="user.id">
          <td>{{ user.id }}</td>
          <td>{{ user.name }}</td>
          <td>{{ user.login }}</td>
          <td>{{ user.date_added }}</td>
          <td>
            <button @click="send(user.id)" class="btn btn-primary">Wyślij</button>
          </td>
        </tr>
      </tbody>
    </table>

    <nav>
      <ul class="pagination">
        <li
          v-for="page in totalPages"
          :key="page"
          @click="changePage(page)"
          :class="{
            'page-item': true,
            active: currentPage === page
          }"
        >
          <a class="page-link">{{ page }}</a>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      users: [],
      search: "",
      apiKey: localStorage.getItem("APIREKRUTACJA") || "",
      currentPage: 1,
      sortBy: null,
      sortOrder: null
    };
  },
  computed: {
    filteredUsers() {
      return this.users.filter(
        user =>
          user.name.includes(this.search) || user.login.includes(this.search)
      );
    },
    paginatedUsers() {
      const startIndex = (this.currentPage - 1) * 10;
      return this.filteredUsers.slice(startIndex, startIndex + 10);
    },
        totalPages() {
      return Math.ceil(this.filteredUsers.length / 10);
    }
  },
  methods: {
  fetchData() {
  axios
    .post("https://app.linkhouse.co/rekrutacja/api", {
      api_key: this.apiKey
    })
    .then(response => {
      if (response.data && response.data.msg === 'error') {
        console.error("Błąd API:", response.data.errors);
        alert("Wystąpił błąd podczas ładowania danych. Błąd API: " + response.data.errors);
      } else if (response.data && Array.isArray(response.data.response)) { // Zmieniamy tutaj sprawdzenie na response.data.response
        this.users = response.data.response; // Zmieniamy przypisanie na response.data.response
      } else {
        console.error("Nieprawidłowy format danych:", response.data);
        alert("Wystąpił błąd podczas ładowania danych. Nieprawidłowy format danych.");
      }
    })
    .catch(error => {
      alert("Wystąpił błąd podczas ładowania danych: " + error);
    });
},



    storeApiKey() {
      localStorage.setItem("APIREKRUTACJA", this.apiKey);
    },
    changePage(page) {
      this.currentPage = page;
    },
    sort(field) {
      if (this.sortBy === field) {
        this.sortOrder = this.sortOrder === "asc" ? "desc" : "asc";
      } else {
        this.sortBy = field;
        this.sortOrder = "asc";
      }

      this.users.sort((a, b) => {
        if (this.sortOrder === "asc") {
          return a[field] > b[field] ? 1 : -1;
        } else {
          return a[field] < b[field] ? 1 : -1;
        }
      });
    },
    send(id) {
      axios
        .post("https://app.linkhouse.co/rekrutacja/ping", {
          user_id: id,
          api_key: this.apiKey
        })
        .then(() => {
          alert("Dane zostały wysłane pomyślnie!");
        })
        .catch(error => {
          alert("Wystąpił błąd podczas wysyłania danych: " + error);
        });
    }
  },
  created() {
    if (this.apiKey) {
      this.fetchData();
    }
  }
};
</script>

<style scoped>
* {
  box-sizing: border-box;
}

input[type='text'] {
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin-right: 10px;
}

input[type='text']::placeholder {
  color: #999;
}

button {
  cursor: pointer;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th {
  background-color: #f2f2f2;
  padding: 8px 16px;
  cursor: pointer;
}

th:hover {
  background-color: #ddd;
}

td {
  padding: 8px 16px;
  border: 1px solid #f2f2f2;
}

tr:nth-child(even) {
  background-color: #f8f8f8;
}

tr:hover {
  background-color: #f1f1f1;
}

.pagination {
  display: inline-block;
  padding-left: 0;
  margin: 20px 0;
  border-radius: 4px;
}

.page-item {
  display: inline;
}

.page-item > .page-link {
  position: relative;
  float: left;
  padding: 6px 12px;
  margin-left: -1px;
  line-height: 1.428571429;
  text-decoration: none;
  background-color: #fff;
  border: 1px solid #ddd;
}

.page-item:first-child > .page-link {
  margin-left: 0;
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
}

.page-item:last-child > .page-link {
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
}

.page-item.active > .page-link,
.page-item.active > .page-link:hover {
  z-index: 2;
  color: #fff;
  background-color: #337ab7;
  border-color: #337ab7;
  cursor: default;
}

.page-item.disabled > .page-link,
.page-item.disabled > .page-link:hover {
  color: #777;
  cursor: not-allowed;
  background-color: #fff;
  border-color: #ddd;
}

.page-link:hover {
  z-index: 2;
  color: #23527c;
  background-color: #eee;
  border-color: #ddd;
}
</style>


